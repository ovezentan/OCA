public interface Doctor {
	static String getCharacterName(){
		return "Dr. Peter Venkman";
	}
}
public interface FamousMovie {
	static String getMovieName(){
		String movieName = "Ghostbusters";
		return movieName;
	}
}
public class Character {
	private int age;
	private boolean fiction = true;
	
	public Character(int age) {
		this.age = age;
	}
	public int getAge() {
		return age;
	}
	public boolean isFiction() {
		return fiction;
	}
}
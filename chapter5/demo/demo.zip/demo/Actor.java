public interface Actor {
	public String getFirstName();
	public String getLastName();
	public String getFullName(); 
}
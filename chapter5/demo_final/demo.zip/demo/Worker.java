public class Worker extends Character{
	public Worker(String name, String description, int feature){
		super(name, description,feature);
	}
}
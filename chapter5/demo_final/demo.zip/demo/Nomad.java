public class Nomad extends Tourist {
    public Nomad(String name, String description){
		super(name, description, Character.OPPORTUNITIES); 
		footprint = 'n';
	}
	
}
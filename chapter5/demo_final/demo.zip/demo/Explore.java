import java.util.*;
public interface Explore {
	public void explore(Country countryToExplore, Character character);
    public char getFootprint();		
}
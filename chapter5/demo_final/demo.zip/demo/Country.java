public class Country {
	private String name;
	
	
	public Country(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}	
	public void print(char footprint){
		setFootprint(footprint);
	}
	
	private void setFootprint(char footprint){
		 //return footprint;
	}
	public void explore(Country countryToExplore, Character character){
		
	}

}
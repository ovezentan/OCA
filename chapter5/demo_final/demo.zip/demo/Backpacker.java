public class Backpacker extends Tourist {
    public Backpacker(String name, String description){
		super(name, description,Character.LEARNERS); 
		footprint = 'b';
	}
}
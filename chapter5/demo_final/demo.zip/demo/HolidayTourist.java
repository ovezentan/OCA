public class HolidayTourist extends Tourist{
    public HolidayTourist (String name, String description){
		super(name, description, Character.INTERACTION); 
		footprint = 'n';
	}
	
}